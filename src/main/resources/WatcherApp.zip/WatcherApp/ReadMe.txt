1.Open the command prompt.

2.Goto the MrllWatcherServices.jar path (EX: C:\WatcherApp).

3.Type the following command to watch the folder,

	java -jar MrllWatcherServices.jar pathtoWatch [Ex: "D:\Program Files\Quark\Quark Publishing Platform\Server"].


If any problem persists or modifications in files,check for the log file in the path (C:\WatcherApp\logs\mrllwatcher.log)

Note * :
Once the command prompt is closed,watcher service will be stopped..

